var menudata={children:[
{text:"Pàgina principal",url:"index.html"},
{text:"Classes",url:"annotated.html",children:[
{text:"Llista de Classes",url:"annotated.html"},
{text:"Membres de Classes",url:"functions.html",children:[
{text:"Tot",url:"functions.html",children:[
{text:"a",url:"functions.html#index_a"},
{text:"c",url:"functions.html#index_c"},
{text:"d",url:"functions.html#index_d"},
{text:"e",url:"functions.html#index_e"},
{text:"g",url:"functions.html#index_g"},
{text:"i",url:"functions.html#index_i"},
{text:"k",url:"functions.html#index_k"},
{text:"l",url:"functions.html#index_l"},
{text:"n",url:"functions.html#index_n"},
{text:"o",url:"functions.html#index_o"},
{text:"p",url:"functions.html#index_p"},
{text:"r",url:"functions.html#index_r"},
{text:"~",url:"functions.html#index_0x7e"}]},
{text:"Funcions",url:"functions_func.html",children:[
{text:"a",url:"functions_func.html#index_a"},
{text:"c",url:"functions_func.html#index_c"},
{text:"d",url:"functions_func.html#index_d"},
{text:"e",url:"functions_func.html#index_e"},
{text:"i",url:"functions_func.html#index_i"},
{text:"l",url:"functions_func.html#index_l"},
{text:"n",url:"functions_func.html#index_n"},
{text:"o",url:"functions_func.html#index_o"},
{text:"p",url:"functions_func.html#index_p"},
{text:"r",url:"functions_func.html#index_r"},
{text:"~",url:"functions_func.html#index_0x7e"}]},
{text:"Variables",url:"functions_vars.html"},
{text:"Definicions de Tipus",url:"functions_type.html"}]}]},
{text:"Fitxers",url:"files.html",children:[
{text:"Llista dels Fitxers",url:"files.html"},
{text:"Membres de Fitxers",url:"globals.html",children:[
{text:"Tot",url:"globals.html"},
{text:"Funcions",url:"globals_func.html"}]}]}]}
