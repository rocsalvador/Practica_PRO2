var searchData=
[
  ['distancies',['distancies',['../class_cjt__clusters.html#a8e94e53830e3224d791dcf7dbd0a6082',1,'Cjt_clusters::distancies()'],['../class_especie.html#ad4bbf9359ebc17c3c7f501bc31c86509',1,'Especie::distancies()']]]
];
