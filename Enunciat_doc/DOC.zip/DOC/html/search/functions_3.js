var searchData=
[
  ['eliminar_5fesp_5fdist',['eliminar_esp_dist',['../class_especie.html#a2a63fa33f9297beec7b57a86fe55ce2a',1,'Especie']]],
  ['eliminar_5fespecie',['eliminar_especie',['../class_cjt__especies.html#a6de3583aff6835d743fc9493c7b38576',1,'Cjt_especies']]],
  ['escriure_5fcjt_5fespecies',['escriure_cjt_especies',['../class_cjt__especies.html#a8bc985ceafb3bb0e5f3c68ba52a36e86',1,'Cjt_especies']]],
  ['especie',['Especie',['../class_especie.html#a597cfbcc08d584338ffe2f5105f9e9c1',1,'Especie']]],
  ['existeix_5fcluster',['existeix_cluster',['../class_cjt__clusters.html#af85ce29152ee18987f391a2d27af59b5',1,'Cjt_clusters']]],
  ['existeix_5fespecie',['existeix_especie',['../class_cjt__especies.html#a7fa2f303eb4e3065d87174a1c3e71942',1,'Cjt_especies']]]
];
