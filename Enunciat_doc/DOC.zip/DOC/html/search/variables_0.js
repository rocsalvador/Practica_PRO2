var searchData=
[
  ['colleccio_5fclusters',['colleccio_clusters',['../class_cjt__clusters.html#aea7d6362517dd16cbd12736a3da50021',1,'Cjt_clusters']]]
];
