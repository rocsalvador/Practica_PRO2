var searchData=
[
  ['inventari',['inventari',['../class_cjt__especies.html#aa253bc335c8c8176b8ece5c49a15c5f3',1,'Cjt_especies']]]
];
