var searchData=
[
  ['neteja_5fclusters',['neteja_clusters',['../class_cjt__clusters.html#a70aca86e77c34ce652d857b16cc2572f',1,'Cjt_clusters']]],
  ['num_5fclusters',['num_clusters',['../class_cjt__clusters.html#a6a240452c7964e1d6b7d54df7ee58563',1,'Cjt_clusters']]]
];
