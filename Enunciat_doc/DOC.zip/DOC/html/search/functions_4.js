var searchData=
[
  ['imprimeix_5farbre_5ffilogenetic',['imprimeix_arbre_filogenetic',['../class_cjt__clusters.html#a952291f47c4dd2edf62b3c110bee24f2',1,'Cjt_clusters']]],
  ['imprimeix_5fcluster',['imprimeix_cluster',['../class_cjt__clusters.html#a732366a2fd16153e162fd838d25b5a56',1,'Cjt_clusters']]],
  ['imprimir_5farbre',['imprimir_arbre',['../_cjt__clusters_8cc.html#ac7539e7b223cc6042be093b32ac8b016',1,'Cjt_clusters.cc']]],
  ['imprimir_5fdistancies',['imprimir_distancies',['../class_especie.html#a305c663aa9f2c8b596e940067fdd6177',1,'Especie']]],
  ['imprimir_5ftaula_5fdistancies',['imprimir_taula_distancies',['../class_cjt__clusters.html#a2ee45d5dabc656adf8d7d356239f57c6',1,'Cjt_clusters::imprimir_taula_distancies()'],['../class_cjt__especies.html#aeb2402fbb6b5cc5eeea31981c51110bc',1,'Cjt_especies::imprimir_taula_distancies()']]],
  ['inicialitza_5fclusters',['inicialitza_clusters',['../class_cjt__especies.html#a568357e9132b16cfe7280e29e6e89cfb',1,'Cjt_especies']]]
];
