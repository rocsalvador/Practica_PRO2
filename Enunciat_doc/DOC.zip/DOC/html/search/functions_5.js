var searchData=
[
  ['llegir_5fcjt_5fespecies',['llegir_cjt_especies',['../class_cjt__especies.html#a12bd759f16126d0e34b06ecf15575456',1,'Cjt_especies']]]
];
