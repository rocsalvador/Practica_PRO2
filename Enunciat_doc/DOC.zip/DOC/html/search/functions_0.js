var searchData=
[
  ['afegeix_5fespecie',['afegeix_especie',['../class_cjt__especies.html#a542ea997b387b5bac131ba7bcb23aec3',1,'Cjt_especies']]],
  ['afegir_5fcluster',['afegir_cluster',['../class_cjt__clusters.html#a2a27f4c57c217eeec5e91777dda19c9d',1,'Cjt_clusters']]],
  ['afegir_5fdist_5fcluster',['afegir_dist_cluster',['../class_cjt__clusters.html#a928bbb5f0ee0756d291ad28e453892bb',1,'Cjt_clusters']]]
];
