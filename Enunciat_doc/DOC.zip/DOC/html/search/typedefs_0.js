var searchData=
[
  ['dist_5fcluster',['dist_cluster',['../class_cjt__clusters.html#a9138a363184004ad38221f340abfccd5',1,'Cjt_clusters']]]
];
