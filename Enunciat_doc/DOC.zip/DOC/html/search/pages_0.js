var searchData=
[
  ['espècies_2c_20clusters_20i_20arbres',['Espècies, clusters i arbres',['../index.html',1,'']]]
];
